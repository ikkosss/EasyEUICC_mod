.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_bar:I = 0x7f090034

.field public static final action_bar_activity_content:I = 0x7f090035

.field public static final action_bar_container:I = 0x7f090036

.field public static final action_bar_root:I = 0x7f090037

.field public static final action_bar_spinner:I = 0x7f090038

.field public static final action_bar_subtitle:I = 0x7f090039

.field public static final action_bar_title:I = 0x7f09003a

.field public static final action_context_bar:I = 0x7f09003c

.field public static final action_menu_divider:I = 0x7f09003f

.field public static final action_menu_presenter:I = 0x7f090040

.field public static final action_mode_bar:I = 0x7f090041

.field public static final action_mode_bar_stub:I = 0x7f090042

.field public static final action_mode_close_button:I = 0x7f090043

.field public static final activity_chooser_view_content:I = 0x7f090046

.field public static final add:I = 0x7f090047

.field public static final alertTitle:I = 0x7f090049

.field public static final buttonPanel:I = 0x7f09006a

.field public static final checkbox:I = 0x7f090077

.field public static final checked:I = 0x7f090078

.field public static final content:I = 0x7f09008d

.field public static final contentPanel:I = 0x7f09008e

.field public static final custom:I = 0x7f090096

.field public static final customPanel:I = 0x7f090097

.field public static final decor_content_parent:I = 0x7f09009c

.field public static final default_activity_button:I = 0x7f09009d

.field public static final edit_query:I = 0x7f0900d5

.field public static final expand_activities_button:I = 0x7f0900e5

.field public static final expanded_menu:I = 0x7f0900e6

.field public static final group_divider:I = 0x7f0900ff

.field public static final home:I = 0x7f090108

.field public static final icon:I = 0x7f09010f

.field public static final image:I = 0x7f090115

.field public static final listMode:I = 0x7f09012b

.field public static final list_item:I = 0x7f09012c

.field public static final message:I = 0x7f09014d

.field public static final multiply:I = 0x7f090171

.field public static final none:I = 0x7f090183

.field public static final normal:I = 0x7f090184

.field public static final off:I = 0x7f09018e

.field public static final on:I = 0x7f090190

.field public static final parentPanel:I = 0x7f0901ac

.field public static final progress_circular:I = 0x7f0901c7

.field public static final progress_horizontal:I = 0x7f0901c8

.field public static final radio:I = 0x7f0901d4

.field public static final screen:I = 0x7f0901ea

.field public static final scrollIndicatorDown:I = 0x7f0901ec

.field public static final scrollIndicatorUp:I = 0x7f0901ed

.field public static final scrollView:I = 0x7f0901ee

.field public static final search_badge:I = 0x7f0901f1

.field public static final search_bar:I = 0x7f0901f2

.field public static final search_button:I = 0x7f0901f3

.field public static final search_close_btn:I = 0x7f0901f4

.field public static final search_edit_frame:I = 0x7f0901f5

.field public static final search_go_btn:I = 0x7f0901f6

.field public static final search_mag_icon:I = 0x7f0901f7

.field public static final search_plate:I = 0x7f0901f8

.field public static final search_src_text:I = 0x7f0901f9

.field public static final search_voice_btn:I = 0x7f0901fa

.field public static final select_dialog_listview:I = 0x7f0901fd

.field public static final shortcut:I = 0x7f090204

.field public static final spacer:I = 0x7f09021c

.field public static final split_action_bar:I = 0x7f090220

.field public static final src_atop:I = 0x7f090225

.field public static final src_in:I = 0x7f090226

.field public static final src_over:I = 0x7f090227

.field public static final submenuarrow:I = 0x7f090234

.field public static final submit_area:I = 0x7f090235

.field public static final tabMode:I = 0x7f090239

.field public static final textSpacerNoButtons:I = 0x7f09024c

.field public static final textSpacerNoTitle:I = 0x7f09024d

.field public static final title:I = 0x7f09025a

.field public static final titleDividerNoCustom:I = 0x7f09025b

.field public static final title_template:I = 0x7f09025c

.field public static final topPanel:I = 0x7f090261

.field public static final unchecked:I = 0x7f09026f

.field public static final uniform:I = 0x7f090270

.field public static final up:I = 0x7f090272

.field public static final wrap_content:I = 0x7f090287


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
